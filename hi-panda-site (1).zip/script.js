
const message = document.getElementById("message");
const hour = new Date().getHours();

if (hour >= 5 && hour < 12) {
  message.textContent = "Good Morning, my cute Panda! 🌸🐾";
} else if (hour >= 18 || hour < 5) {
  message.textContent = "Good Night, sleep tight Panda! 🌙💤";
} else {
  message.textContent = "Have a beautiful day, Panda! 💖";
}
